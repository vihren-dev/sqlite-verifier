"""Retain one instrumented frozen-v5 load with the unchanged process-group guard."""

import argparse
from collections import Counter
import cProfile
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import pstats
from resource import RUSAGE_SELF, getrusage
import sys
from time import monotonic_ns
import traceback

from t04c_metadata import Json, conditions, digest, save, tree

SOURCE_COMMIT = "5d15607fdf78d0a209b539ca158939739b54d377"
"""Reviewed source of the fresh receipt and subsequent CPU-stage diagnostic."""


def utc() -> str:
    """Retain actual UTC separately from monotonic instrumented durations."""
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def identity(source: Path, archive: Path) -> dict[str, Json]:
    """Hash full source and frozen inputs, Python, archive and the actual observer files."""
    python = Path(sys.executable).resolve(strict=True)
    return {"source": tree(source), "frozenV5": tree(source / "conformance/corpus-v5"),
            "helpers": tree(Path(__file__).parent),
            "archive": {"path": str(archive), "sha256": digest(archive), "bytes": archive.stat().st_size},
            "python": {"path": str(python), "sha256": digest(python), "version": sys.version}}


def load_conditions(output: Path) -> dict[str, Json]:
    """State this observer's actual identity-read scope without claiming runtime use."""
    observed = conditions(output)
    observed["identityReads"] = "full source/frozen/helper/archive/Python bytes read before and after, outside load timing"
    return observed


def load_once(source: Path, output: Path) -> int:
    """Profile the real all-binding load once; retain failures and pstats before other work."""
    from conformance.corpus import load
    from conformance.corpus_shards import profiles
    from conformance.native_storage import serialized
    profiler = cProfile.Profile()
    started = {"utc": utc(), "monotonicNs": monotonic_ns(), "pid": os.getpid(), "group": os.getpgrp()}
    save(output / "load-start.json", started)
    before_cpu = getrusage(RUSAGE_SELF)
    failure: dict[str, Json] | None = None
    records: list[dict[str, Json]] = []
    manifest: dict[str, Json] | None = None
    profiler.enable()
    try:
        manifest, records = load(source / "conformance/corpus-v5")
    except BaseException as error:
        failure = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
    finally:
        profiler.disable()
    ended = {"utc": utc(), "monotonicNs": monotonic_ns()}
    after_cpu = getrusage(RUSAGE_SELF)
    profiler.dump_stats(output / "load.pstats")
    result = {"diagnosticOnly": True, "kind": "instrumented-load-only", "started": started, "ended": ended,
              "instrumentedLoadSeconds": (ended["monotonicNs"] - started["monotonicNs"]) / 1e9,
              "parentUserSeconds": after_cpu.ru_utime - before_cpu.ru_utime,
              "parentSystemSeconds": after_cpu.ru_stime - before_cpu.ru_stime, "failure": failure,
              "loadedRecordCount": len(records), "corpusVersion": manifest["corpusVersion"] if manifest else None,
              "casesSha256": manifest["casesSha256"] if manifest else None}
    save(output / "load-result.json", result)
    if manifest is not None:
        save(output / "loaded-manifest.json", manifest)
        save(output / "loaded-binding.json", {"manifestSha256": digest(source / "conformance/corpus-v5/manifest.json"),
            "profiles": profiles(records), "declaredProfiles": manifest["executionProfiles"],
            "profileBindingSha256": hashlib.sha256(serialized(manifest["executionProfiles"])).hexdigest(),
            "names": [record["name"] for record in records], "byPart": dict(Counter(record["part"] for record in records)),
            "nativeVersions": dict(Counter(str(record["nativeVersion"]) for record in records))})
    for name, order in (("self-time", pstats.SortKey.TIME), ("cumulative", pstats.SortKey.CUMULATIVE)):
        with (output / (name + ".txt")).open("x") as stream:
            statistics = pstats.Stats(profiler, stream=stream).sort_stats(order)
            statistics.print_stats()
            statistics.print_callers()
    print(json.dumps(result), flush=True)
    return 0 if manifest is not None else 1


def capture(source: Path, output: Path, archive: Path) -> int:
    """Retain complete before/after identities and original streams even if the load fails."""
    from conformance.replay_tiers import PHASE_LIMIT_SECONDS
    from tests.runtime_support import CommandTimeout, run_command
    save(output / "capture-start.json", {"utc": utc(), "monotonicNs": monotonic_ns(),
        "sourceCommit": SOURCE_COMMIT, "phaseLimitSeconds": PHASE_LIMIT_SECONDS, "diagnosticOnly": True})
    before = identity(source, archive)
    save(output / "identity-before.json", before)
    save(output / "conditions-before.json", load_conditions(output))
    try:
        command = run_command([sys.executable, "-B", str(Path(__file__).resolve()), "load", str(source),
            str(output), str(archive)], cwd=source, timeout=PHASE_LIMIT_SECONDS, artifacts=output / "commands")
        timed_out = False
    except CommandTimeout as error:
        command, timed_out = error.result, True
    after = identity(source, archive)
    save(output / "identity-after.json", after)
    save(output / "conditions-after.json", load_conditions(output))
    save(output / "receipt.json", {"diagnosticOnly": True, "kind": "instrumented-load-only",
        "sourceCommit": SOURCE_COMMIT, "phaseLimitSeconds": PHASE_LIMIT_SECONDS,
        "captureEnded": {"utc": utc(), "monotonicNs": monotonic_ns()}, "bindingsUnchanged": before == after,
        "command": {"returncode": command.returncode, "stdout": command.stdout, "stderr": command.stderr,
                    "elapsedSeconds": command.elapsed, "timedOut": timed_out},
        "loadStarted": (output / "load-start.json").exists(), "loadResultRetained": (output / "load-result.json").exists(),
        "profileRetained": (output / "load.pstats").exists()})
    print(json.dumps({"returncode": command.returncode, "bindingsUnchanged": before == after, "timedOut": timed_out}), flush=True)
    return 0 if command.returncode == 0 and before == after and not timed_out else 1


def main() -> int:
    """Configure source imports only in the main process; an existing output cannot restart."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("capture", "load"))
    for name in ("source", "output", "archive"):
        parser.add_argument(name, type=Path)
    options = parser.parse_args()
    source, output, archive = (getattr(options, name).resolve(strict=True) for name in ("source", "output", "archive"))
    sys.path.insert(0, str(source))
    sys.dont_write_bytecode = True
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        return capture(source, output, archive) if options.mode == "capture" else load_once(source, output)
    except BaseException as error:
        save(output / "capture-failure.json", {"utc": utc(), "monotonicNs": monotonic_ns(),
            "type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc(),
            "loadStarted": (output / "load-start.json").exists(), "profileRetained": (output / "load.pstats").exists()})
        raise


if __name__ == "__main__":
    raise SystemExit(main())
