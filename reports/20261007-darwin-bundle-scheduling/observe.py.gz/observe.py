"""Retain one normal exact bundle build without changing its source or suite budget."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import runpy
import signal
import subprocess
import sys
import threading
from time import monotonic_ns


ROOT = Path(__file__).resolve().parent
DRV = Path('/nix/store/bbqk4g8b9d3xa32qam8dk9d5ycw8gpxy-sqlite-verifier-test-bundle-1.drv')
RUNTIME = Path('/nix/store/dsb751zkkicbqgxca8lkk3zf4rcz8i85-sqlite-verifier-runtime-1')
METADATA = Path('/Users/tzankomatev/work/sqlite-verifier-headroom/build/20261007-t04c-acceptance/helpers/t04c_metadata.py')
TOOLS = runpy.run_path(str(METADATA))
tree = TOOLS['tree']
digest = TOOLS['digest']
settings = {'max-jobs': 1, 'cores': 8, 'sandbox': False, 'sandbox-fallback': True,
            'timeout': 0, 'max-silent-time': 0, 'build-users-group': 'nixbld'}


def stamp() -> dict[str, object]:
    """Bind actual UTC and monotonic clocks independently."""
    return {'utc': datetime.now(timezone.utc).isoformat(timespec='microseconds'),
            'monotonicNs': monotonic_ns()}


def save(name: str, value: object) -> None:
    """Create evidence once without overwriting an earlier observation."""
    with (ROOT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write('\n')


def declaration() -> dict[str, str]:
    """Read the actual immutable failed derivation's selected environment values."""
    data = DRV.read_text()
    result = {}
    for key in ('src', 'out', 'system', 'nativeBuildInputs', 'installPhase', 'stdenv'):
        match = re.search(r'\("' + key + r'",("(?:[^"\\]|\\.)*")\)', data)
        if match is None:
            raise ValueError(f'Missing derivation field: {key}')
        result[key] = json.loads(match.group(1))
    return result


def identity(fields: dict[str, str]) -> dict[str, object]:
    """Hash every source, installed runtime and pytest interpreter artifact outside build timing."""
    return {'source': tree(Path(fields['src'])), 'runtime': tree(RUNTIME),
            'pytestPython': tree(Path(fields['nativeBuildInputs'])),
            'derivation': {'path': str(DRV), 'sha256': digest(DRV)},
            'observer': {'path': str(Path(__file__)), 'sha256': digest(Path(__file__))},
            'metadataHelper': {'path': str(METADATA), 'sha256': digest(METADATA)}}


def main() -> None:
    """Build exactly once, retain original streams and copy a successful JUnit without rewriting it."""
    fields = declaration()
    output = Path(fields['out'])
    if output.exists():
        raise RuntimeError('Output appeared after validity inspection; do not call a cached result fresh')
    before = identity(fields)
    save('identity-before.json', before)
    save('preflight.json', {'observed': stamp(), 'declaration': fields, 'previousValidityExit': 1,
        'previousValidityStderr': f"error: path '{output}' is not valid\n", 'outputExisted': False,
        'observerPython': {'path': str(Path(sys.executable).resolve()), 'version': sys.version},
        'host': dict(platform.uname()._asdict()), 'cpuCount': os.cpu_count(),
        'loadAverage': list(os.getloadavg()), 'selectedNixSettings': settings,
        'qualification': 'Identity reads precede timing; OS file caches are not flushed. Stream event times mark received complete lines, not pytest call boundaries.'})
    command = ['nix-build', str(DRV), '--no-out-link', '--keep-failed', '--max-jobs', '1',
               '--option', 'sandbox', 'true', '--option', 'sandbox-fallback', 'false',
               '--extra-experimental-features', 'nix-command flakes']
    started = stamp()
    save('build-start.json', {'started': started, 'command': command, 'outerLimitSeconds': 900,
        'suiteLimitSeconds': 420, 'expectedCases': 42, 'sourceHead': '555b9a745a21755e32d3da3aa98a78c30629e8fe'})
    lock = threading.Lock()
    timed_out = False
    with (ROOT / 'stdout.log').open('xb') as stdout, (ROOT / 'stderr.log').open('xb') as stderr, \
            (ROOT / 'stream-events.jsonl').open('x', encoding='utf-8') as events:
        process = subprocess.Popen(command, cwd='/Users/tzankomatev/work/sqlite-verifier-catalog',
                                   stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        print(json.dumps({'buildStarted': True, 'pid': process.pid, 'started': started, 'command': command}), flush=True)

        def copy(stream: object, destination: object, name: str) -> None:
            """Keep exact original bytes and separately timestamp received log lines."""
            while line := stream.readline():
                destination.write(line)
                destination.flush()
                with lock:
                    events.write(json.dumps({'stream': name, 'observed': stamp(), 'bytes': len(line),
                                             'sha256': hashlib.sha256(line).hexdigest()}) + '\n')
                    events.flush()

        threads = [threading.Thread(target=copy, args=(process.stdout, stdout, 'stdout')),
                   threading.Thread(target=copy, args=(process.stderr, stderr, 'stderr'))]
        for thread in threads:
            thread.start()
        try:
            returncode = process.wait(timeout=900)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            returncode = process.wait(timeout=10)
        ended = stamp()
        for thread in threads:
            thread.join(timeout=10)
        if any(thread.is_alive() for thread in threads):
            raise RuntimeError('A stream remained open after process termination; retain this observation without rerunning')
    save('build-result.json', {'started': started, 'ended': ended, 'returncode': returncode,
        'timedOut': timed_out, 'elapsedSeconds': (ended['monotonicNs'] - started['monotonicNs']) / 1e9,
        'pid': process.pid, 'command': command, 'outputExists': output.exists()})
    after = identity(fields)
    save('identity-after.json', after)
    junit = output / 'junit.xml'
    if junit.is_file():
        (ROOT / 'junit.xml').write_bytes(junit.read_bytes())
    save('summary.json', {'returncode': returncode, 'timedOut': timed_out, 'identitiesUnchanged': before == after,
        'elapsedSeconds': (ended['monotonicNs'] - started['monotonicNs']) / 1e9,
        'junitRetained': junit.is_file(), 'junitSha256': digest(junit) if junit.is_file() else None})
    print((ROOT / 'summary.json').read_text(), flush=True)


if __name__ == '__main__':
    main()
