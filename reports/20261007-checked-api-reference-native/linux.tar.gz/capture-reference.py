"""Retain one exact native reference invocation without changing reviewed source."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys
import time


def digest(path: Path) -> str:
    """Identify original artifact bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value: object) -> None:
    """Write complete capture data separately from public source."""
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def utc() -> str:
    """Record an unambiguous wall-clock boundary."""
    return datetime.now(timezone.utc).isoformat()


def snapshot(source: Path, expected: dict) -> dict:
    """Check every archived regular file, executable bit and symlink target."""
    actual = {}
    for name, entry in expected.items():
        path = source / name
        mode = path.lstat().st_mode
        if entry['kind'] == 'symlink':
            assert stat.S_ISLNK(mode), name
            actual[name] = {'kind': 'symlink', 'target': os.readlink(path)}
            assert actual[name]['target'] == entry['target'], name
        else:
            assert stat.S_ISREG(mode), name
            actual[name] = {'kind': 'file', 'sha256': digest(path), 'size': path.stat().st_size,
                            'executable': bool(mode & 0o111)}
            assert actual[name]['sha256'] == entry['sha256'], name
            assert actual[name]['size'] == entry['size'], name
            assert actual[name]['executable'] == (entry['mode'] == '100755'), name
    return actual


def main() -> int:
    """Run the unchanged public recipe once and retain success or failure evidence."""
    task = Path(sys.argv[1]).resolve()
    source = task / 'source'
    manifest = json.loads((task / 'source-manifest.json').read_text())
    revision = manifest['source_revision']
    assert sys.platform == 'linux' and platform.machine() == 'x86_64'
    assert Path.cwd().resolve() == source
    receipt = {'source_revision': revision, 'source_tree': manifest['source_tree'],
               'native': {'platform': sys.platform, 'machine': platform.machine()},
               'capture_helper_sha256': digest(Path(__file__)),
               'source_archive_sha256': digest(task / 'source.tar'),
               'manifest_sha256': digest(task / 'source-manifest.json'),
               'environment_sha256': hashlib.sha256(json.dumps(dict(os.environ), sort_keys=True).encode()).hexdigest(),
               'selected_environment': {key: os.environ.get(key) for key in
                 ('SQLITE_VERIFIER_SYSTEM', 'SQLITE_VERIFIER_SHELL', 'SQLITE_VERIFIER_PYTHON', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL', 'NIX_BUILD_CORES')},
               'commands': [], 'capture_started_utc': utc()}
    save(task / 'source-before.json', snapshot(source, manifest['entries']))

    def run(label: str, command: list[str]) -> subprocess.CompletedProcess:
        """Keep the original command stream, boundaries and exit status."""
        started = time.monotonic_ns()
        row = {'label': label, 'argv': command, 'cwd': str(source), 'started_utc': utc(),
               'started_monotonic_ns': started}
        with (task / (label + '.log')).open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=False)
        row.update({'finished_utc': utc(), 'finished_monotonic_ns': time.monotonic_ns(),
                    'exit_code': result.returncode})
        row['elapsed_seconds'] = (row['finished_monotonic_ns'] - started) / 1e9
        receipt['commands'].append(row)
        save(task / 'receipt.json', receipt)
        return result

    resource = run('resources', ['python3', 'tools/check_resources.py'])
    if resource.returncode:
        receipt['result'] = 'resource-preflight-failed'
        save(task / 'receipt.json', receipt)
        return resource.returncode
    run('nix-version', ['nix', '--version'])
    drv_command = ['nix-instantiate', 'build-support/default.nix', '-A', 'apiReference',
                   '--argstr', 'referenceRevision', revision,
                   '--extra-experimental-features', 'nix-command flakes']
    instantiated = run('instantiate', drv_command)
    if instantiated.returncode:
        return instantiated.returncode
    drv = (task / 'instantiate.log').read_text().splitlines()[-1]
    assert drv.startswith('/nix/store/') and drv.endswith('.drv'), drv
    receipt['derivation'] = drv
    receipt['derivation_sha256'] = digest(Path(drv))
    run('derivation', ['nix', 'derivation', 'show', '--extra-experimental-features', 'nix-command flakes', drv])
    run('expected-output', ['nix-store', '--query', '--outputs', drv])
    expected_output = (task / 'expected-output.log').read_text().strip()
    receipt['expected_output'] = expected_output
    validity = run('output-before-validity', ['nix-store', '--check-validity', expected_output])
    receipt['output_valid_before'] = validity.returncode == 0
    if validity.returncode == 0:
        receipt['result'] = 'already-valid-output-no-build-started'
        save(task / 'receipt.json', receipt)
        return 78
    result = run('reference', ['timeout', '1800', 'just', 'reference', revision])
    save(task / 'source-after.json', snapshot(source, manifest['entries']))
    receipt['source_unchanged'] = (task / 'source-before.json').read_bytes() == (task / 'source-after.json').read_bytes()
    receipt['result'] = 'success' if result.returncode == 0 else 'reference-failed'
    if result.returncode == 0:
        output = (source / 'build/api-reference').resolve(strict=True)
        assert str(output) == expected_output
        receipt['output'] = str(output)
        receipt['output_files'] = sum(path.is_file() for path in output.rglob('*'))
        retained = {}
        for name in ('reference-check.json', 'public-doc-inventory.json', 'doc-gen4-sources.json'):
            shutil.copy2(output / name, task / name)
            retained[name] = {'sha256': digest(task / name), 'bytes': (task / name).stat().st_size}
        receipt['output_metadata'] = retained
        run('output-requisites', ['nix-store', '--query', '--requisites', str(output)])
    receipt['capture_finished_utc'] = utc()
    save(task / 'receipt.json', receipt)
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
