#!/usr/bin/env bash
# Capture the exact public reference recipe in an isolated native task directory.
set -euo pipefail
task_root=/var/tmp/sqlite-verifier-t18b-reference.stMbNq
cd "$task_root"
sha256sum --check transfer.sha256 > transfer-verified.log
mkdir source
tar -xf source.tar -C source
printf '%s\n' 'nix develop path:./nix --command python3 ../capture-reference.py /var/tmp/sqlite-verifier-t18b-reference.stMbNq' > invocation.txt
date -u --iso-8601=ns > invocation-started.txt
cd source
set +e
nix develop path:./nix --command python3 ../capture-reference.py "$task_root"
result=$?
set -e
cd "$task_root"
printf '%s\n' "$result" > invocation-exit.txt
date -u --iso-8601=ns > invocation-finished.txt
exit "$result"
