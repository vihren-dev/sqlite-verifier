#!/usr/bin/env bash
set -eu
cd "$1/source"
sha256sum --check ../source.sha256 > "$2/source-before.log"
test "$(readlink CLAUDE.md)" = AGENTS.md
findmnt -T "$2" -o TARGET,FSTYPE,SOURCE,OPTIONS > "$2/filesystem-before.txt"
cat /proc/loadavg > "$2/load-before.txt"
nix develop path:./nix --command sh -c '
 PYTHONPATH="$PWD" timeout 120 python3 -B "$1/t04c_diagnostic.py" "$1" > "$1/run.log" 2>&1
' -- "$2"
sha256sum --check ../source.sha256 > "$2/source-after.log"
test "$(readlink CLAUDE.md)" = AGENTS.md
findmnt -T "$2" -o TARGET,FSTYPE,SOURCE,OPTIONS > "$2/filesystem-after.txt"
cat /proc/loadavg > "$2/load-after.txt"
printf '%s\n' T04C_LINUX_DIAGNOSTIC_COMPLETE
