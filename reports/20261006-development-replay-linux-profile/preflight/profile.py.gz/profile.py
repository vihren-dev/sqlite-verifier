"""Profile one original T04c phase to separate CPU validation from ordinary-file replay."""

import cProfile
from collections.abc import Callable
import hashlib
import json
import os
from pathlib import Path
import platform
import pstats
import resource
import sys
from time import monotonic_ns
from typing import ParamSpec, TypeVar

from conformance import replay_tiers
from conformance.case_format import Json
from conformance.native_connection import library_path

P = ParamSpec("P")
Result = TypeVar("Result")
SOURCE_COMMIT = "82f2d1786cd732b4b89f813680506ca631239887"
SELECTED_IDENTITIES = 184
PHASE_LIMIT_SECONDS = 120
root = Path.cwd()
output = Path(sys.argv[1]).resolve(strict=True)
runtime = (root / "build/conformance").resolve(strict=True)
storage = output / "native-storage"
storage.mkdir()
paths: list[Path] = []
phases: dict[str, list[dict[str, Json]]] = {}


def hashes() -> dict[str, str]:
    """Bind measured public code, all frozen transport, Python and native/runtime binaries."""
    selected = [Path(__file__), Path(sys.executable).resolve(), library_path().resolve(),
                runtime / "build/sqlite-parser", runtime / ".lake/build/bin/conformance-runner"]
    selected += sorted(path for directory in ("conformance", "migration_check")
                       for path in (root / directory).glob("*") if path.suffix in (".py", ".tcl"))
    selected += sorted(path for name in ("corpus-v1", "corpus-v2", "corpus-v3", "corpus-v4", "corpus-v5", "synthetic-workload")
                       for path in (root / "conformance" / name).rglob("*") if path.is_file())
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in selected}


def metrics() -> dict[str, int | float]:
    """Observe parent/child CPU, block I/O and process bytes without tracing or changing SQLite."""
    own, children = resource.getrusage(resource.RUSAGE_SELF), resource.getrusage(resource.RUSAGE_CHILDREN)
    result: dict[str, int | float] = {
        "parentUserSeconds": own.ru_utime, "parentSystemSeconds": own.ru_stime,
        "childUserSeconds": children.ru_utime, "childSystemSeconds": children.ru_stime,
        "parentInputBlocks": own.ru_inblock, "parentOutputBlocks": own.ru_oublock,
        "childInputBlocks": children.ru_inblock, "childOutputBlocks": children.ru_oublock,
        "parentVoluntaryContextSwitches": own.ru_nvcsw,
        "parentInvoluntaryContextSwitches": own.ru_nivcsw,
    }
    result.update({"procIo." + key: int(value) for line in Path("/proc/self/io").read_text().splitlines()
                   for key, value in [line.split(":", 1)]})
    return result


def timed(name: str, function: Callable[P, Result]) -> Callable[P, Result]:
    """Retain each original call's inclusive wall/CPU/I/O without changing arguments or results."""
    def call(*arguments: P.args, **keywords: P.kwargs) -> Result:
        """Forward exactly one original call and preserve observations even if it fails."""
        before, started = metrics(), monotonic_ns()
        try:
            return function(*arguments, **keywords)
        finally:
            ended, after = monotonic_ns(), metrics()
            phases.setdefault(name, []).append({"wallSeconds": (ended - started) / 1e9,
                "metricsDelta": {key: after[key] - value for key, value in before.items()}})
    return call


original_native = replay_tiers.native_replay


def ordinary_native(records: list[dict[str, Json]]) -> None:
    """Use the original comparator and preserve actual ordinary-file fixture paths."""
    original_native(records, temporary_root=storage, fixture_paths=paths)


before = hashes()
(output / "identity-before.json").write_text(json.dumps(before, indent=2) + "\n")
for name in ("runtime_binding", "load", "bound_records", "select", "checked_replay", "binding"):
    setattr(replay_tiers, name, timed(name, getattr(replay_tiers, name)))
replay_tiers.native_replay = timed("native_replay", ordinary_native)
profiler = cProfile.Profile()
phase_before = metrics()
started = monotonic_ns()
profiler.enable()
try:
    result = replay_tiers.report(root / "conformance/corpus-v5", root / "conformance/synthetic-workload", runtime)
finally:
    profiler.disable()
    ended = monotonic_ns()
    phase_after = metrics()
    profiler.dump_stats(str(output / "diagnostic.pstats"))
    for order in ("cumulative", "tottime"):
        with (output / ("profile-" + order + ".txt")).open("w") as stream:
            pstats.Stats(profiler, stream=stream).sort_stats(order).print_stats(90)
    (output / "stage-observations.json").write_text(json.dumps(phases, indent=2) + "\n")
    after = hashes()
    (output / "identity-after.json").write_text(json.dumps(after, indent=2) + "\n")

assert before == after, "Measurement code, corpus or runtime changed"
assert result["selectedDenominator"] == len(paths) == SELECTED_IDENTITIES
assert result["measurement"]["limitSeconds"] == PHASE_LIMIT_SECONDS
assert all(path.is_relative_to(storage) and path.name == "case.db" for path in paths)
assert not list(storage.iterdir()), "Native fixtures were not cleaned"
old = json.loads((root / "reports/20261002-adr5-review-v5-sample-linux.json").read_text())
fields = ("corpusVersion", "casesSha256", "manifestSha256", "executionProfiles", "denominator",
          "selectedDenominator", "selectedNames", "selectedIdentities", "selectedIdentitiesSha256", "cases", "counts")
comparison = {side: {field: result[side][field] == old[side][field] for field in fields}
              for side in ("generic", "synthetic")}
assert all(all(checks.values()) for checks in comparison.values())
assert result["counts"] == old["counts"] == {"MODEL_UNSUPPORTED": SELECTED_IDENTITIES}
serialization_started = monotonic_ns()
(output / "report.json").write_text(json.dumps(result, indent=2) + "\n")
serialization_seconds = (monotonic_ns() - serialization_started) / 1e9
summary = {"format": "t04c-linux-profile-v1", "note": "instrumented diagnostic, not acceptance measurement",
    "sourceCommit": SOURCE_COMMIT, "runtime": str(runtime), "python": sys.executable,
    "platform": platform.platform(), "machine": platform.machine(), "loadAverageAfter": os.getloadavg(),
    "startedMonotonicNs": started, "endedMonotonicNs": ended,
    "outerInstrumentedSeconds": (ended - started) / 1e9, "measurement": result["measurement"],
    "phaseMetricsDelta": {key: phase_after[key] - value for key, value in phase_before.items()},
    "reportSerializationOutsidePhaseSeconds": serialization_seconds,
    "stageObservations": phases, "comparison": comparison,
    "selectedDenominator": result["selectedDenominator"], "counts": result["counts"],
    "storage": {"root": str(storage), "device": storage.stat().st_dev, "kind": "ordinary SQLite files",
                "fixturePaths": list(map(str, paths)), "fixturesCleaned": True},
    "hashesBefore": before, "hashesAfter": after,
    "qualification": "cProfile and stage probes add overhead; rusage/I/O deltas do not directly measure fsync calls."}
(output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({key: summary[key] for key in ("note", "outerInstrumentedSeconds", "measurement", "selectedDenominator", "counts")}))
