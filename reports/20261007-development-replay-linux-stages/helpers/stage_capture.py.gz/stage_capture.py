"""Retain one instrumented diagnostic with the unchanged 120-second process-group bound."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
from time import monotonic_ns
import traceback

from t04c_metadata import Json, conditions, identity, save

SOURCE_COMMIT = '5d15607fdf78d0a209b539ca158939739b54d377'
"""Reviewed main integration used for both exact-source runtimes and the two fresh phases."""
COMPARISON_FIELDS = ('corpusVersion', 'casesSha256', 'manifestSha256', 'executionProfiles', 'denominator',
    'selectedDenominator', 'selectedNames', 'selectedIdentities', 'selectedIdentitiesSha256', 'cases', 'counts')
"""Frozen identities, exact profiles and verdicts compared with each retained platform receipt."""


def utc() -> str:
    """Keep actual UTC timestamps alongside independent monotonic measurements."""
    return datetime.now(timezone.utc).isoformat(timespec='microseconds')


def phase(source: Path, runtime: Path, output: Path) -> int:
    """Call the real report once with stage observers, retaining result, paths and failures."""
    from conformance.replay_tiers import report
    from t04c_stages import install
    stage_observations = install()
    paths: list[Path] = []
    started = {'utc': utc(), 'monotonicNs': monotonic_ns(), 'pid': os.getpid(), 'group': os.getpgrp()}
    save(output / 'phase-start.json', started)
    result: dict[str, Json] | None = None
    failure: dict[str, Json] | None = None
    try:
        result = report(source / 'conformance/corpus-v5', source / 'conformance/synthetic-workload', runtime,
                        temporary_root=output / 'native-storage', fixture_paths=paths)
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
    ended = {'utc': utc(), 'monotonicNs': monotonic_ns()}
    save(output / 'stage-observations.json', stage_observations)
    if result is not None:
        save(output / 'report.json', result)
    save(output / 'phase-result.json', {'started': started, 'ended': ended,
        'outerPhaseSeconds': (ended['monotonicNs'] - started['monotonicNs']) / 1e9,
        'fixturePaths': list(map(str, paths)), 'failure': failure,
        'fixturesCleaned': not list((output / 'native-storage').iterdir())})
    print(json.dumps({'phaseCompleted': result is not None, 'failure': failure,
        'measurement': result['measurement'] if result is not None else None}), flush=True)
    return 0 if result is not None else 1


def capture(source: Path, runtime: Path, output: Path, archive: Path, helpers: Path) -> int:
    """Retain full before/after identities and receipt even if the target is missed or the phase fails."""
    from conformance.replay_tiers import PHASE_LIMIT_SECONDS
    from tests.runtime_support import CommandTimeout, run_command
    storage = output / 'native-storage'
    storage.mkdir()
    save(output / 'capture-start.json', {'utc': utc(), 'monotonicNs': monotonic_ns(), 'pid': os.getpid(),
                                      'sourceCommit': SOURCE_COMMIT, 'phaseLimitSeconds': PHASE_LIMIT_SECONDS})
    before = identity(source, runtime, archive, helpers)
    save(output / 'identity-before.json', before)
    if not before['leanVersion'].startswith('Lean (version 4.34.1,'):
        raise RuntimeError('Exact-source runtime must use Lean 4.34.1')
    conditions_before = conditions(storage)
    save(output / 'conditions-before.json', conditions_before)
    observation: dict[str, Json]
    try:
        result = run_command([sys.executable, '-B', str(Path(__file__).resolve()), 'phase', str(source),
            str(runtime), str(output), str(archive)], cwd=source, timeout=PHASE_LIMIT_SECONDS,
            artifacts=output / 'commands')
        observation = {'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                       'elapsedSeconds': result.elapsed, 'timedOut': False}
    except CommandTimeout as error:
        result = error.result
        observation = {'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                       'elapsedSeconds': result.elapsed, 'timedOut': True}
    after = identity(source, runtime, archive, helpers)
    save(output / 'identity-after.json', after)
    conditions_after = conditions(storage)
    save(output / 'conditions-after.json', conditions_after)
    report_path = output / 'report.json'
    report = json.loads(report_path.read_bytes()) if report_path.exists() else None
    platform_name = 'linux' if sys.platform == 'linux' else 'darwin'
    historical_path = source / f'reports/20261002-adr5-review-v5-sample-{platform_name}.json'
    historical = json.loads(historical_path.read_bytes())
    comparisons = {side: {field: report[side][field] == historical[side][field] for field in COMPARISON_FIELDS}
                   for side in ('generic', 'synthetic')} if report is not None else None
    phase_result = json.loads((output / 'phase-result.json').read_bytes()) if (output / 'phase-result.json').exists() else None
    valid = report is not None and phase_result is not None and before == after and observation['returncode'] == 0
    if valid:
        paths = phase_result['fixturePaths']
        valid = (report['selectedDenominator'] == len(paths) == len(set(paths)) == 184 and
            report['counts'] == historical['counts'] == {'MODEL_UNSUPPORTED': 184} and
            report['policy'] == historical['policy'] and report['policySha256'] == historical['policySha256'] and
            report['measurement']['limitSeconds'] == PHASE_LIMIT_SECONDS == 120 and
            all(all(values.values()) for values in comparisons.values()) and phase_result['fixturesCleaned'] and
            all(Path(path).is_relative_to(storage) and Path(path).name == 'case.db' for path in paths))
    save(output / 'receipt.json', {'format': 't04c-stage-diagnostic-v1', 'diagnosticOnly': True, 'sourceCommit': SOURCE_COMMIT,
        'captureEnded': {'utc': utc(), 'monotonicNs': monotonic_ns()}, 'command': observation,
        'historicalReceipt': {'path': str(historical_path), 'sha256': before['source']['files'][str(historical_path.relative_to(source))]['sha256']},
        'bindingsUnchanged': before == after, 'comparisons': comparisons, 'phase': phase_result,
        'valid': bool(valid), 'underTarget': report['measurement']['seconds'] < 30 if report is not None else None,
        'measurement': report['measurement'] if report is not None else None,
        'targetSecondsExclusive': 30, 'phaseLimitSeconds': PHASE_LIMIT_SECONDS,
        'conditionsBefore': conditions_before, 'conditionsAfter': conditions_after})
    print(json.dumps({'valid': bool(valid), 'underTarget': report['measurement']['seconds'] < 30 if report is not None else None,
                     'measurement': report['measurement'] if report is not None else None}), flush=True)
    return 0 if valid else 1


def main() -> int:
    """Configure imports only under the main guard so spawned workers do not restart the capture."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('capture', 'phase'))
    for argument in ('source', 'runtime', 'output', 'archive'):
        parser.add_argument(argument, type=Path)
    options = parser.parse_args()
    source, runtime, output, archive = (getattr(options, name).resolve(strict=True)
                                      for name in ('source', 'runtime', 'output', 'archive'))
    sys.path.insert(0, str(source))
    sys.dont_write_bytecode = True
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    try:
        return phase(source, runtime, output) if options.mode == 'phase' else capture(source, runtime, output, archive, Path(__file__).parent.resolve())
    except BaseException as error:
        save(output / 'capture-failure.json', {'utc': utc(), 'monotonicNs': monotonic_ns(),
            'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc(),
            'phaseStarted': (output / 'phase-start.json').exists(), 'reportRetained': (output / 'report.json').exists()})
        raise


if __name__ == '__main__':
    raise SystemExit(main())
