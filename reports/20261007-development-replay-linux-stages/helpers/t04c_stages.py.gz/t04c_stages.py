"""Observe existing parent-stage calls and reaped child CPU without changing results."""

from functools import wraps
from resource import RUSAGE_CHILDREN, RUSAGE_SELF, getrusage
from time import monotonic_ns
from typing import Callable, ParamSpec, TypeVar

from t04c_metadata import Json

Parameters = ParamSpec("Parameters")
Result = TypeVar("Result")


def observed(stage: str, function: Callable[Parameters, Result],
             observations: dict[str, Json]) -> Callable[Parameters, Result]:
    """Keep the original result or exception and append actual wall and CPU deltas."""
    @wraps(function)
    def call(*args: Parameters.args, **kwargs: Parameters.kwargs) -> Result:
        """Measure one parent call, including direct child CPU reaped in that call."""
        parent_before, children_before = getrusage(RUSAGE_SELF), getrusage(RUSAGE_CHILDREN)
        started = monotonic_ns()
        failure: str | None = None
        try:
            return function(*args, **kwargs)
        except BaseException as error:
            failure = type(error).__name__
            raise
        finally:
            ended = monotonic_ns()
            parent_after, children_after = getrusage(RUSAGE_SELF), getrusage(RUSAGE_CHILDREN)
            calls = observations.setdefault(stage, [])
            assert isinstance(calls, list)
            calls.append({"startedMonotonicNs": started, "endedMonotonicNs": ended,
                "wallSeconds": (ended - started) / 1e9, "failureType": failure,
                "metricsDelta": {"parentUserSeconds": parent_after.ru_utime - parent_before.ru_utime,
                    "parentSystemSeconds": parent_after.ru_stime - parent_before.ru_stime,
                    "childrenUserSeconds": children_after.ru_utime - children_before.ru_utime,
                    "childrenSystemSeconds": children_after.ru_stime - children_before.ru_stime}})
    return call


def install() -> dict[str, Json]:
    """Wrap only the existing report's stage names in the diagnostic parent process."""
    import conformance.replay_tiers as tiers
    observations: dict[str, Json] = {}
    tiers.runtime_binding = observed("runtime_binding", tiers.runtime_binding, observations)
    tiers.load = observed("load", tiers.load, observations)
    tiers.bound_records = observed("bound_records", tiers.bound_records, observations)
    tiers.select = observed("select", tiers.select, observations)
    tiers.replay_native_cases = observed("replay_native_cases", tiers.replay_native_cases, observations)
    tiers.checked_replay = observed("checked_replay", tiers.checked_replay, observations)
    tiers.binding = observed("binding", tiers.binding, observations)
    return observations
