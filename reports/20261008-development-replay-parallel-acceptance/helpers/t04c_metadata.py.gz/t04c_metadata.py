"""Capture actual source, runtime, filesystem and machine identities outside phase timing."""

import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from typing import TypeAlias

Json: TypeAlias = None | bool | int | float | str | list['Json'] | dict[str, 'Json']


def digest(path: Path) -> str:
    """Read exact file bytes in bounded chunks, including large compiler artifacts."""
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()


def fail_walk(error: OSError) -> None:
    """Unreadable directories invalidate an identity instead of disappearing from its scope."""
    raise error


def tree(root: Path) -> dict[str, Json]:
    """Follow installed links, recording each reference and hashing each actual regular file."""
    files: dict[str, Json] = {}
    references: dict[str, Json] = {}
    visited: set[Path] = set()
    for directory, names, leaves in os.walk(root, followlinks=True, onerror=fail_walk):
        path = Path(directory)
        resolved = path.resolve(strict=True)
        references[str(path.relative_to(root))] = str(resolved)
        if resolved in visited:
            names.clear()
            continue
        visited.add(resolved)
        names.sort()
        for name in sorted(leaves):
            file = path / name
            if not file.is_file():
                raise ValueError(f'Nonregular identity file: {file}')
            files[str(file.relative_to(root))] = {'sha256': digest(file), 'bytes': file.stat().st_size,
                'resolved': str(file.resolve(strict=True)), 'link': os.readlink(file) if file.is_symlink() else None}
    return {'root': str(root), 'files': files, 'references': references}


def command(arguments: list[str]) -> str:
    """Retain real machine and filesystem observations with short subprocess deadlines."""
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=10, check=False)
    if result.returncode:
        raise RuntimeError(f'{arguments} exited {result.returncode}: {result.stderr}')
    return result.stdout


def conditions(storage: Path) -> dict[str, Json]:
    """Describe the observed host, load and selected ordinary-file filesystem without claiming cache residency."""
    usage = shutil.disk_usage(storage)
    disk = command(['df', '-P', str(storage)])
    filesystem = {'df': disk, 'findmnt': command(['findmnt', '-T', str(storage), '-o', 'TARGET,FSTYPE,SOURCE,OPTIONS', '--json'])} if sys.platform == 'linux' else {
        'df': disk, 'diskutil': command(['diskutil', 'info', disk.splitlines()[-1].split()[0]])}
    memory = command(['sh', '-c', 'cat /proc/meminfo']) if sys.platform == 'linux' else command(['sysctl', 'hw.memsize', 'hw.logicalcpu'])
    return {'platform': platform.platform(), 'uname': dict(platform.uname()._asdict()),
        'cpuCount': os.cpu_count(), 'memory': memory, 'loadAverage': list(os.getloadavg()),
        'storageRoot': str(storage), 'storageDevice': storage.stat().st_dev,
        'storageBytes': {'total': usage.total, 'used': usage.used, 'free': usage.free},
        'filesystem': filesystem, 'osFileCaches': 'not flushed; residency is not observed',
        'identityReads': 'full source/runtime/helper bytes read before and after, outside phase timing'}


def identity(source: Path, runtime: Path, archive: Path, helpers: Path) -> dict[str, Json]:
    """Bind complete source/runtime trees, Python, archive, helpers and every declared native engine."""
    from conformance.native_connection import library_path
    from conformance.native_library import library_binary
    versions: set[str] = set()
    for relative in ('conformance/corpus-v5/manifest.json', 'conformance/synthetic-workload/corpus/manifest.json'):
        manifest = json.loads((source / relative).read_bytes())
        versions.update(profile['engineVersion'] for profile in manifest['executionProfiles'])
    libraries = {version: library_path(library_binary(version)).resolve(strict=True) for version in sorted(versions)}
    python = Path(sys.executable).resolve(strict=True)
    return {'source': tree(source), 'runtime': tree(runtime), 'helpers': tree(helpers),
        'archive': {'path': str(archive), 'sha256': digest(archive), 'bytes': archive.stat().st_size},
        'python': {'path': str(python), 'sha256': digest(python), 'version': sys.version},
        'nativeLibraries': {version: {'path': str(path), 'sha256': digest(path)} for version, path in libraries.items()},
        'leanVersion': command([str(runtime / 'lean/bin/lean'), '--version'])}


def save(path: Path, value: Json) -> None:
    """Write one complete JSON observation exactly once; earlier evidence is never overwritten."""
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write('\n')
