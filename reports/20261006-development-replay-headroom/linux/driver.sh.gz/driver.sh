#!/usr/bin/env bash
set -eu
cd "$1/source"
sha256sum --check ../source.sha256 > ../source-before.log
test "$(readlink CLAUDE.md)" = AGENTS.md
nix develop path:./nix --command sh -c '
 timeout 900 nix-build build-support/default.nix -A conformance --out-link build/conformance --extra-experimental-features "nix-command flakes" > build/headroom-runtime-build.log 2>&1
'
nix develop path:./nix --command sh -c '
 mkdir -p build/headroom-acceptance-linux
 PYTHONPATH="$PWD" timeout 120 python3 -B ../measure.py > build/headroom-acceptance-linux/run.log 2>&1
'
sha256sum --check ../source.sha256 > ../source-after.log
test "$(readlink CLAUDE.md)" = AGENTS.md
printf '%s\n' T04C_LINUX_MEASUREMENT_COMPLETE
