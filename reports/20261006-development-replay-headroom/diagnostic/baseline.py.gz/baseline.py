"""Profile the unchanged fresh tier once with explicit native fixture storage."""
import cProfile
import json
import os
from pathlib import Path
import pstats
from time import monotonic

from conformance import replay_tiers

runtime = Path('/nix/store/2pm5l48v8lk5v3p1yqbc3hx3jj1w2ylr-sqlite-verifier-conformance')
output = Path('build/headroom-profile')
storage = output / 'native-storage'
storage.mkdir(exist_ok=True)
phases = {}
paths = []


def timed(name, function):
    """Retain each original boundary's elapsed wall time without changing its validations."""
    def call(*arguments, **keywords):
        started = monotonic()
        try:
            return function(*arguments, **keywords)
        finally:
            phases[name] = phases.get(name, 0.0) + monotonic() - started
    return call


native = replay_tiers.native_replay


def fresh(records):
    """Select file storage explicitly while retaining the original native comparisons."""
    return native(records, temporary_root=storage.resolve(), fixture_paths=paths)


for name in ('runtime_binding', 'load', 'bound_records', 'select', 'checked_replay', 'binding'):
    setattr(replay_tiers, name, timed(name, getattr(replay_tiers, name)))
replay_tiers.native_replay = timed('native_replay', fresh)
profiler = cProfile.Profile()
profiler.enable()
started = monotonic()
result = replay_tiers.report(Path('conformance/corpus-v5'), Path('conformance/synthetic-workload'), runtime)
seconds = monotonic() - started
profiler.disable()
profiler.dump_stats(str(output / 'baseline.pstats'))
with (output / 'baseline-profile.txt').open('w') as stream:
    pstats.Stats(profiler, stream=stream).strip_dirs().sort_stats('cumulative').print_stats(45)
(output / 'baseline-report.json').write_text(json.dumps(result, indent=2) + '\n')
summary = {'note': 'instrumented diagnostic, not final acceptance measurement', 'phasesSeconds': phases,
    'reportSeconds': seconds, 'runtime': str(runtime), 'python': os.sys.executable,
    'storageRoot': str(storage.resolve()), 'fixtureCount': len(paths),
    'selectedDenominator': result['selectedDenominator'], 'counts': result['counts']}
(output / 'baseline-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
