"""Retain one fresh phase with original validations and explicitly audited ordinary-file storage."""
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
from time import monotonic_ns

from conformance import replay_tiers
from conformance.native_connection import library_path

root = Path.cwd()
output = root / 'build/headroom-acceptance-darwin'
runtime = Path('/nix/store/2pm5l48v8lk5v3p1yqbc3hx3jj1w2ylr-sqlite-verifier-conformance')
storage = output / 'native-storage'
storage.mkdir()
paths = []


def hashes():
    """Read actual code, frozen transport, native library and executable identities outside phase timing."""
    selected = [Path(__file__), Path(sys.executable).resolve(), library_path().resolve(),
                runtime / 'build/sqlite-parser', runtime / '.lake/build/bin/conformance-runner']
    selected += sorted(path for directory in ('conformance', 'migration_check')
                       for path in (root / directory).glob('*') if path.suffix in ('.py', '.tcl'))
    selected += sorted(path for name in ('corpus-v1','corpus-v2','corpus-v3','corpus-v4','corpus-v5','synthetic-workload')
                       for path in (root / 'conformance' / name).rglob('*') if path.is_file())
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in selected}


native = replay_tiers.native_replay


def ordinary_native(records):
    """Call the unchanged comparator with explicit file storage; retain every actual fixture path."""
    return native(records, temporary_root=storage.resolve(), fixture_paths=paths)


before = hashes()
replay_tiers.native_replay = ordinary_native
started = monotonic_ns()
result = replay_tiers.report(root / 'conformance/corpus-v5', root / 'conformance/synthetic-workload', runtime)
ended = monotonic_ns()
after = hashes()
assert before == after, 'Measurement code, corpus or runtime changed'
assert result['selectedDenominator'] == len(paths) == 184
assert result['measurement']['limitSeconds'] == 120
assert all(Path(path).is_relative_to(storage) and Path(path).name == 'case.db' for path in paths)
assert not list(storage.iterdir()), 'Native fixtures were not cleaned'
old = json.loads((root / 'reports/20261002-adr5-review-v5-sample-darwin.json').read_text())
paired = {}
for side in ('generic','synthetic'):
    fields = ('corpusVersion','casesSha256','manifestSha256','executionProfiles','denominator',
              'selectedDenominator','selectedNames','selectedIdentities','selectedIdentitiesSha256','cases','counts')
    paired[side] = {field: result[side][field] == old[side][field] for field in fields}
assert all(all(checks.values()) for checks in paired.values())
assert result['counts'] == old['counts'] == {'MODEL_UNSUPPORTED': 184}
summary = {'format': 't04c-fresh-phase-v1', 'platform': platform.platform(), 'machine': platform.machine(),
    'python': sys.executable, 'runtime': str(runtime), 'startedMonotonicNs': started,
    'endedMonotonicNs': ended, 'outerPhaseSeconds': (ended-started)/1e9,
    'measurement': result['measurement'], 'targetSeconds': 30, 'underTarget': result['measurement']['seconds'] < 30,
    'storage': {'root': str(storage), 'device': storage.stat().st_dev, 'kind': 'ordinary SQLite files',
                'fixturePaths': paths, 'fixturesCleaned': True},
    'pairedHistoricalReceipt': 'reports/20261002-adr5-review-v5-sample-darwin.json',
    'comparison': paired, 'selectedDenominator': result['selectedDenominator'], 'counts': result['counts'],
    'hashesBefore': before, 'hashesAfter': after, 'loadAverage': os.getloadavg()}
(output / 'report.json').write_text(json.dumps(result, indent=2)+'\n')
(output / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({key: summary[key] for key in ('outerPhaseSeconds','measurement','underTarget','selectedDenominator','counts')}))
