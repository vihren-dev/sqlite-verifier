"""Compare exact shard validation with process transport before changing production loading."""

from concurrent.futures import ProcessPoolExecutor
import gzip
import hashlib
import json
from multiprocessing import get_context
from pathlib import Path
from time import monotonic

from conformance.case_format import Json
from conformance.corpus_shards import payload_records, source_path
from conformance.native_storage import serialized


def validate(inputs: tuple[bytes, dict[str, Json]]) -> list[dict[str, Json]]:
    """Run the unchanged complete per-shard validator in either execution context."""
    return payload_records(*inputs)


def main() -> None:
    """Retain both actual durations and equal ordered outputs without native or model calls."""
    directory = Path("conformance/corpus-v5")
    manifest_bytes = (directory / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    inputs = []
    bindings = {}
    combined = hashlib.sha256()
    for shard in manifest["shards"]:
        path = source_path(directory, shard["path"])
        raw = path.read_bytes()
        bindings[str(path)] = hashlib.sha256(raw).hexdigest()
        payload = gzip.decompress(raw)
        assert hashlib.sha256(payload).hexdigest() == shard["casesSha256"]
        combined.update(payload)
        inputs.append((payload, shard))
    assert combined.hexdigest() == manifest["casesSha256"]
    started = monotonic()
    serial = [validate(item) for item in inputs]
    serial_seconds = monotonic() - started
    started = monotonic()
    with ProcessPoolExecutor(max_workers=4, mp_context=get_context("spawn")) as executor:
        parallel = list(executor.map(validate, inputs))
    parallel_seconds = monotonic() - started
    assert parallel == serial
    records = [record for shard in serial for record in shard]
    assert len(records) == manifest["recordedCases"]
    assert (directory / "manifest.json").read_bytes() == manifest_bytes
    assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest for path, digest in bindings.items())
    result = {"diagnostic_only": True, "platform": "aarch64-darwin", "workers": 4,
        "shards": len(inputs), "records": len(records), "serial_seconds": serial_seconds,
        "parallel_seconds_including_process_transport": parallel_seconds,
        "equal_ordered_records": True, "case_digest": combined.hexdigest(),
        "expanded_record_digest": hashlib.sha256(serialized(records)).hexdigest(),
        "input_hashes": bindings, "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "native_or_model_replay": False, "cache_residency_observed": False}
    Path("build/t04c-load-feasibility/result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "input_hashes"}, indent=2))


if __name__ == "__main__":
    main()
