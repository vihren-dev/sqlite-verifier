"""Retain one bounded native conformance build and its exact reviewed input/output identities."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from time import monotonic_ns

from t04c_metadata import Json, conditions, digest, identity, save, tree

BUILD_LIMIT_SECONDS = 900
"""Use the unchanged configured conformance build bound; no replay runs in this helper."""


def stamp() -> dict[str, Json]:
    """Retain actual UTC and monotonic boundaries without reconstructing lost observations."""
    return {"utc": datetime.now(timezone.utc).isoformat(), "monotonicNs": monotonic_ns()}


def inputs(source: Path, archive: Path, helpers: Path) -> dict[str, Json]:
    """Bind all public files, helpers, Python and declared native engines before and after the build."""
    from conformance.native_connection import library_path
    from conformance.native_library import library_binary
    versions: set[str] = set()
    for relative in ("conformance/corpus-v5/manifest.json", "conformance/synthetic-workload/corpus/manifest.json"):
        versions.update(profile["engineVersion"] for profile in json.loads((source / relative).read_bytes())["executionProfiles"])
    libraries = {version: library_path(library_binary(version)).resolve(strict=True) for version in sorted(versions)}
    python = Path(sys.executable).resolve(strict=True)
    return {"source": tree(source), "helpers": tree(helpers),
        "archive": {"path": str(archive), "sha256": digest(archive), "bytes": archive.stat().st_size},
        "python": {"path": str(python), "sha256": digest(python), "version": sys.version},
        "declaredNativeLibraries": {version: {"path": str(path), "sha256": digest(path)} for version, path in libraries.items()}}


def main() -> None:
    """Check the resource guard, build once, then retain every output file without native or model replay."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--platform", required=True)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    source, helpers = root / "public-source", root / "helpers"
    output = root / args.platform
    output.mkdir()
    sys.path.insert(0, str(source))
    from tools.check_resources import check_resources
    from tests.runtime_support import CommandTimeout, run_command
    save(output / "capture-start.json", stamp())
    check_resources(source, temporary_root=output)
    save(output / "guard.json", {"passed": True, "observed": stamp()})
    save(output / "conditions-before.json", conditions(output))
    archive = root / "source-c3e8f518-public.tar"
    before = inputs(source, archive, helpers)
    save(output / "inputs-before.json", before)
    evaluated = run_command(["nix-instantiate", "--eval", "--strict", "--json",
        "--extra-experimental-features", "nix-command flakes", "--expr",
        "(import ./build-support/default.nix {}).conformance.outPath"], cwd=source, timeout=30, artifacts=output / "eval")
    if evaluated.returncode:
        raise ValueError(evaluated.diagnostic())
    runtime = Path(json.loads(evaluated.stdout))
    save(output / "expected-runtime.json", {"path": str(runtime), "existedBefore": runtime.is_dir()})
    if runtime.is_dir():
        save(output / "runtime-before.json", tree(runtime))
    save(output / "build-start.json", stamp())
    command = ["nix-build", "build-support/default.nix", "-A", "conformance", "--no-out-link",
               "--extra-experimental-features", "nix-command flakes"]
    try:
        result = run_command(command, cwd=source, timeout=BUILD_LIMIT_SECONDS, artifacts=output / "build")
    except CommandTimeout as error:
        save(output / "build-result.json", {"ended": stamp(), "returncode": error.result.returncode, "timedOut": True})
        raise
    save(output / "build-result.json", {"ended": stamp(), "returncode": result.returncode, "timedOut": False})
    if result.returncode or result.stdout.strip() != str(runtime):
        raise ValueError(result.diagnostic())
    after = inputs(source, archive, helpers)
    save(output / "inputs-after.json", after)
    save(output / "identity-after.json", identity(source, runtime, archive, helpers))
    save(output / "conditions-after.json", conditions(output))
    valid = before == after
    save(output / "receipt.json", {"kind": "fresh-native-runtime-build-only", "valid": valid,
        "runtime": str(runtime), "sourceRevision": "c3e8f5186e2865b5cdc0ea5af1a9d0924531752a",
        "buildLimitSeconds": BUILD_LIMIT_SECONDS, "buildReturncode": result.returncode,
        "inputIdentitiesEqual": valid, "replayInvocations": 0, "ended": stamp()})
    if not valid:
        raise ValueError("Runtime build changed reviewed inputs; inspect the retained before and after manifests")
    print(json.dumps({"valid": valid, "runtime": str(runtime), "replayInvocations": 0}), flush=True)


if __name__ == "__main__":
    main()
